package com.example.relojcontador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button bnt_Sum, bnt_Rest, btn_Rese;
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void sumarCont(View v){

        TextView tv1 = findViewById(R.id.txt_Contador);

        int cuenta = Integer.valueOf((String) tv1.getText());

        int suma =cuenta+1;
        if (suma >= 100) { suma = 100; }

        tv1.setText(   String.valueOf(suma));
    }
    public void restarCont(View v){
        TextView tv1 = findViewById(R.id.txt_Contador);

        int cuenta = Integer.valueOf((String) tv1.getText());

        int resta =cuenta-1;

        if (resta <= 0) { resta = 0; }

        tv1.setText(String.valueOf(resta));

    }

    public void resetCont(View v){
        TextView tv1 = findViewById(R.id.txt_Contador);

        int cuenta = Integer.valueOf((String) tv1.getText());

        int reset =0;

        tv1.setText(String.valueOf(reset));

    }
}