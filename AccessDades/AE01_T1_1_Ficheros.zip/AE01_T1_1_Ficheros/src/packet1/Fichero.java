package packet1;

import java.io.File;
import java.util.Scanner;

public class Fichero {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		File fichero = new File("..\\AE01_T1_1_Ficheros\\src\\packet1");
		metodosFichero metodo = new metodosFichero(fichero);

		// Iniciamos variable para escoger las opciones
		int opciones = 0;

		// Iniciamos bucle que muestra las opciones
		while (opciones != 6) {
			
			System.out.println("�En que te puedo ayudar?");
			System.out.println("1.- Obtener Informacion");
			System.out.println("2.- Crear Carpeta");
			System.out.println("3.- Crear Fichero");
			System.out.println("4.- Eliminar");
			System.out.println("5.- Renombrar");
			System.out.println("6.- Salir");
			
			opciones = sc.nextInt();

			// Iniciamos el swtich para la elecci�n de la opci�n
			switch (opciones) {
			
			case 1:
				System.out.println("Has elegido, obtener informaci�n.");
				System.out.println("Estas visualizando la informaci�n del directorio packet1 ");
				
				metodo.obtenerInformacion();
				break;
				
			case 2:
				System.out.println("Has elegido, crear un Directorio.");
				System.out.println("Dime el nombre que quieres ponerle al nuevo Directorio");

				File creDir = new File("..\\AE01_T1_1_Ficheros\\src\\packet1\\" + sc.next());
				
				metodo.crearCarpeta(creDir);

				break;
				
			case 3:
				System.out.println("Has elegido, crear un Fichero de texto");
				System.out.println("Dime el nombre que quieres ponerle al nuevo Fichero de texto");

				File creFich = new File("..\\AE01_T1_1_Ficheros\\src\\packet1\\" + sc.next() + ".txt");

				metodo.crearFichero(creFich);
				break;
				
			case 4:
				System.out.println("Has elegido, eliminar un Fichero o Directorio.");
				System.out.println("Dime el nombre del directorio que quieres eliminar y si es un archivo dime tambien su extension");

				File eliminar = new File("..\\AE01_T1_1_Ficheros\\src\\packet1\\" + sc.next());
				
				metodo.eliminarCosas(eliminar);
				break;
				
			case 5:
				System.out.println("Has elegido, renombrar un Fichero o Directorio.");
				System.out.println("Dime el nombre del directorio que quieres renombrar y si es un archivo dime tambien su extension");

				File ficheroRe = new File("..\\AE01_T1_1_Ficheros\\src\\packet1\\" + sc.next());
				
				System.out.println("Dime el NUEVO nombre del directorio y si es un archivo dime tambien su extension");
				
				File renombrar = new File("..\\AE01_T1_1_Ficheros\\src\\packet1\\" + sc.next());
				
				metodo.renombrarCosas(ficheroRe, renombrar);
				break;
				
			case 6:
				System.out.println("Gracias por utiliziarme.");
				break;
				
			}

		}
		sc.close();
	}
}
