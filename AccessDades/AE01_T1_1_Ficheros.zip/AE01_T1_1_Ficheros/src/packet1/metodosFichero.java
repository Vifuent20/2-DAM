package packet1;

import java.io.File;

public class metodosFichero {

	File fichero;

	public metodosFichero() {

	}

	public metodosFichero(File fichero) {
		this.fichero = fichero;
	}

	/**
	 * 
	 * @metodo crearCarpeta Este m�todo obtiene informacion del directorio packet1
	 * @return Y este m�todo nos devuelve la informaci�n del directorio y si hay otro directorio dentro nos lo avisa y dice si tama�o.
	 * 
	 **/
	
	public void obtenerInformacion() {

		for (int i = 0; i < fichero.list().length; i++) {
			System.out.println(fichero.list()[i]);
		}

		if (fichero.isDirectory()) {
			System.out.print(" - Esto es una carpeta");

			System.out.println(" y ocupa.." + (fichero.getTotalSpace()/1024)/1024/1024 + "KB");
		}
		System.out.println(" ");

	}
	
/**
 * 
 * @metodo crearCarpeta Este m�todo crea una carpeta en el directorio. 
 * @param creDir Es el par�metro donde se guarda el nombre del directorio  que vamos a crear.
 * @return Y este m�todo nos devuelve un comentario de si ha sido posible crear o no la carpeta y nos crea la carpeta.
 * 
 **/
	
	public void crearCarpeta(File creDir) {
			
		try {
			
			creDir.mkdir();
			System.out.println("Has creado un directorio");

		} catch (Exception e) {

			System.out.println("No se ha podido crear el directorio");
			e.printStackTrace();

		}System.out.println(" ");
	}

/**
* 
* @metodo crearCarpeta Este m�todo crea un fichero en el directorio. 
* @param creFich Es el par�metro donde se guarda el nombre del fichero  que vamos a crear.
* @return Y este m�todo nos devuelve un comentario de si ha sido posible crear o no el fichero y nos crea el fichero.
* 
**/	
	
	public void crearFichero(File creFich) {

		try {
			creFich.createNewFile();
			System.out.println("Has creado un fichero");

		} catch (Exception e) {

			System.out.println("No se ha podido crear el fichero");
			e.printStackTrace();

		}System.out.println(" ");

	}
/**
* 
* @metodo crearCarpeta Este m�todo elimina un fichero o un directorio. 
* @param eliminar Es el par�metro donde se guarda el nombre del fichero que vamos a eliminar.
* @return Y este m�todo nos devuelve un comentario de si ha sido posible crear o no el fichero y nos crea el fichero.
* 
**/		
	
	public void eliminarCosas(File eliminar) {
		try {

			eliminar.delete();
			System.out.println("Se ha eliminado correctamente");

		} catch (Exception e) {
			System.out.println("No se ha podido eliminar");
			e.printStackTrace();
		}System.out.println(" ");
	}
	
/**
* 
* @metodo crearCarpeta Este m�todo renombra un fichero o directorio. 
* @param ficheroRe Es el par�metro donde se guarda el nombre del fichero que vamos a renombrar.
* @param renombrar Es el par�metro donde se guarda el NUEVO nombre del fichero.
* @return Y este m�todo nos devuelve un comentario de si ha sido posible renombrar o no el fichero o directorio y les cambia el nombre.
* 
**/	
	
	public void renombrarCosas(File ficheroRe, File renombrar) {
		try {
			
			ficheroRe.renameTo(renombrar);
			System.out.println("Renombrado correctamente");
			
		} catch (Exception e) {
			
			System.out.println("Error al renomenar");
			e.printStackTrace();
			
		}System.out.println(" ");
		
	}

}
