#Actividad U2 AP1.1

kilos = input ('¿Cuanto pesas?')
metros = input ('¿Cuanto mides?')
altura = float(metros) * float(metros) 
IMC = (float(kilos) / float(altura))

print("Tu IMC es de ", IMC)
