#Actividad U2 AP1.9

print("Dime un numero")
num1 = int(input())
print("Dime un numero")
num2 = int(input())
print("Dime un numero")
num3 = int(input())

if num1 > num2 and num1 > num3:
	print(num1,"Es el numero mas grande")
if num2 > num1 and num2 > num3:
	print(num2,"Es el numero mas grande")
if num3 > num1 and num3 > num2:
	print(num3,"Es el numero mas grande")

