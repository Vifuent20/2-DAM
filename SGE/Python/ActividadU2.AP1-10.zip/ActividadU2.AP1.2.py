#Actividad U2 AP1.2

x = input ('Dime un numero')
y = input ('Dime otro numero')
Div = float(x) % float (y)

if Div == 0:
	print("La división es exacta")
else :
	print("La división NO es exacta")
